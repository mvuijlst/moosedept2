---
title: "Build, min of meer"
date: 2022-12-05T09:09:27Z
draft: false
tags: ['site']
---

Ik zou eens moeten zoeken op een beter systeem om die site hier te deployen. Een `xcopy public \\files\mvuijlst\www\users /s /y` vanuit de folder op mijn computer is misschien niet de ideale manier, maar ik heb de indruk dat ik geen github actions kan hebben op de github van het werk. Denk ik. 
---
title: "Children of Memory"
date: 2022-12-05T21:27:28Z
draft: false
tags: ['gelezen']
---

Tralala, het volgende boek in de *Children of Time*-serie is uit: *Children of Memory*. Het begint denk ik als een prequel (ik lees nooit verder dan "Earth is failing" en dat de bewoners van de aarde wanhopig proberen te vluchten in een ruimteschip); ik hoop dat het verder gaat dan het tweede boek. 

Dat tweede boek was namelijk geëindigd op een punt waar ik van zou content geweest zijn als dat het einde van het hele verhaal was -- een einde waarbij de mensheid zowat een Culture-niveau haalt maar dan op sommige vlakken nog een eind verder. Als we weer terugkeren naar vóór de gebeurtenissen in het tweede boek en niet verder gaan, zou ik teleurgesteld zijn. 

Maar kijk. Het is alvast een excuus om weer eens mijn Kindle boven te halen -- of het zou moeten zijn dat ik het alsnog als audiobook beluister (maar dan moet ik wel nog een maand wachten want mijn oudste dochter heeft gedomme mijn laatste credit bij Audible opgebruikt een paar dagen geleden).
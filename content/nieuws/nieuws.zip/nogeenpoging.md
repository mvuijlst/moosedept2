---
title: "Nog maar eens een poging"
date: 2024-10-02 19:18:40
draft: false
tags: ['verbouwingen']
---

Gisteren een dakwerker aangeraden gekregen die eigenlijk een algemene aannemer is met een groot netwerk van stielmannen. Vandaag een mail gestuurd, en nu zijn al mijn ledematen gekruisd. 

Het zou _zo_ enorm wijs zijn als het deze keer zou lukken. 

(Update twee dagen later: contact met mens! Afspraak volgende week!)
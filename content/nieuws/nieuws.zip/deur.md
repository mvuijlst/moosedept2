---
title: "Deur, poging zoveel"
date: 2023-01-19T12:53:11+01:00
draft: false
tags: ['huis', 'deur']
---

Nog maar eens de gegevens van de deur aan een aantal mogelijke deurmakers gestuurd. 

Ik kan de mail gewoon copypasten van al de vorige keren: 

<blockquote>
Van de mensen van Stedenbouw moeten we iets hebben dat er aan de buitenkant uitziet zoals het nu is: een houten deur, met glas, met smeedwerk ervoor. 

Dit is wat we onze architect jaren geleden had geschreven (maar misschien is de techniek ondertussen al verder gevorderd):

- Hoogte: 240cm. Breedte: 207cm (buiten); 223cm (afstand tussen muren binnen)
- Dubbele voordeur met 3-puntsluiting met haken en aanslag onderaan (blauwe hardsteen, max 20mm)
- Kruk binnenzijde, trekker buitenzijde (in smeedwerk ingewerkt)
- Brievenbus links (in zelfde afwerking als smeedwerk)
- Naar binnen opendraaiende ramen. We hadden staan: “superisolerende, gelaagde beglazing GGG Thermobel Top N+; Stratobel 33.2 met opaalfilm”, maar van als het goed isoleert en doorschijnend maar niet doorzichtig is (bvb gezandstraald), is het goed. - De kleur van de deur zelf is NCS S 3040-B.

Voor het smeedwerk waren we al gaan spreken met Peter De Bruyn (https://www.smederijdebruyn.be/). Het smeedwerk moet in twee delen, en we zouden graag een tekening hebben die in de twee deurpanelen doorloopt, dus zoals op het beeld met de blauwe deuren, in een art nouveau-achtige stijl -- maar dat is werk voor een smid, natuurlijk. 
</blockquote>
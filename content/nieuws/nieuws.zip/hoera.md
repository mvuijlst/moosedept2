---
title: "Huis: gevel! dak!"
date: 2022-12-01T11:36:06+01:00
draft: false
tags: ['huis','dak','gevel']
---

De kogel is door de kerk: de gevel gaat ververst worden midden-december, en het dak gaat ververst worden als de dakmens de dakpannen binnenkrijgt die hij besteld heeft maanden geleden. 
---
title: "Tiens een site met Hugo"
date: 2022-11-22T11:36:06+01:00
draft: false
tags: ['site']
---

Als wij [op het werk](https://ugent.be) Hugo gaan gebruiken, is het misschien geen slecht idee om dat zelf ook eens allemaal op te frissen. 

Dus bij dezen. 
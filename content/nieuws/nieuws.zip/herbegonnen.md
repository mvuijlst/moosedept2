---
title: "Herbegonnen"
date: 2023-01-26T14:56:51+01:00
draft: false
tags: ['huis', 'gevel']
---

Er staat *as we speak* een mens aan de muur te schrapen buiten. Dat wil zeggen dat ze na een maand of zo stil liggen wegens feesten en slecht weer, herbegonnen zijn. 

Nog een laag die dan afgevlakt wordt, dan nog een laag die afgevlakt wordt, en dan schilderen en nog eens schilderen. 

Of misschien komt dat schilderen tussen twee lagen, geen idee. 

En dan nog eens kijken of ze iets doen aan de afvoerbuizen en of het houten gedoe bovenaan de gevel in orde komt. 
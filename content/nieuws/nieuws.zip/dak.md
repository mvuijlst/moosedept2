---
title: "Dak, binnenkort"
date: 2023-05-19T12:07:28Z
draft: false
tags: ['huis', 'dak']
---

De mens van het dak komt! Er is een vergunning om met een kraan en een container voor de deur te staan van 16/6 tot 30/6. Ik vind dat ikweetniethoespannend. 
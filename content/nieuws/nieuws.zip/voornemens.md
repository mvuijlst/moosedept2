---
title: "Voornemens 2023"
date: 2023-01-01T18:31:07+01:00
draft: false
tags: ['gelezen','leven']
---

Een nieuw jaar, dus tijd voor voornemens. 

Ik ga dit jaar wat extra dingen bijhouden, naast waar ik naar kijk en wat ik lees en hoe lang de kat op mijn schoot zit. Ik ga proberen bij te houden welk eten we klaarmaken. Ik heb de _indruk_ dat we nogal veel hetzelfde eten: tijd om dat eens hard te maken. 

Daarnaast: meer boeken lezen. Het steekt, dat ik <a href="../../gelezen/2022gelezen">zo weinig gelezen heb in 2022</a>. Ik ga de lijsten van wat goed was in 2022 afgaan, en daar wat van op mijn Kindle zetten. En daarnaast ook een nieuwe selectie Audible doen. 

Wat meer stabiele dashboards maken van dingen ook, misschien. In plaats van zoals nu altijd alles ad hoc te doen. Eens kijken of ik een betere manier van ingestie kan doen, ook, in plaats van zoals nu een mengeling van org mode en Goodreads en Google Keep en dingen. Een pipeline opzetten ook misschien. Mijn ding van "hoe lang nog" eens van nul af aan hermaken. 

Ik zou nog een lijst met andere, meer persoonlijk voornemens kunnen posten, maar dan maar niet, denk ik. 
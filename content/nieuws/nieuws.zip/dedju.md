---
title: "Stekelnoten deels om zeep"
date: 2022-10-28T11:36:06+01:00
draft: false
tags: ['hof']
---

De kuisvrouw heeft de inhoud van een pot vol zeiknatte aarde over de stekelnoten gakapt. De stekelnoten aan de rechterkant aan de kant van het huis zijn volledig bedolven en dus waarschijnlijk dood. Dedju. 

En de kat heeft ook aan de rechterkant maar dan aan de kant van het achterhuis de stekelnoten kapotgpist. Of -gekakt, ik wil er van af zijn. Ook dedju. 

Hopen dat het goed komt tegen volgend jaar. 
---
title: Gevel gedaan!
date: 2023-02-28T20:01:19Z
draft: false
tags: ['huis','gevel']
---

De gevel is klaar, hoera hoezee. Het heeft wat langer geduurd dan ik had gedacht, maar het is absoluut verklaarbaar waarom: te koud om te werken, te nat om te drogen, dat soort dingen. 

Maar nu is het klaar. En ik ben er zeer content van. 

Nu nog de deur. En het dak. En de rest. 
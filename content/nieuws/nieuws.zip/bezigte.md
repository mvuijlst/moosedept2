---
title: "Bezig aan de gevel"
date: 2022-12-18T18:53:14Z
draft: false
tags: ['huis','gevel']
---

Er staat nog altijd een stelling tegen de gevel, en er zijn al heelder stukken pleisterwerk van gehaald. Op dit moment is het te koud om verder te werken, denk ik, en dus list het wat stil. Tot waarschijnlijk ergens na nieuwjaar, vermoed ik. En dan moet er geverfd worden. 

De kleur moet nog duidelijk gemaakt worden, en ook dat het eigenlijk twee kleuren zijn: een heel heel lichtblauw vanboven en een wat donkerder lichtbluaw dat meer naar het grijs gaat vanonder. En zien dat het allemaal in dezelfde tint is als de vensters. 
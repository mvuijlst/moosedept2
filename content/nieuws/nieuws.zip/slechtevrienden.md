---
title: De slechte vrienden
date: 2022-12-04T11:25:40Z
draft: false
tags: ['gekeken']
---

Alsmaar minder dingen die via decentrale backup bekeken worden, maar soms kan het niet anders. 't Is azo. 
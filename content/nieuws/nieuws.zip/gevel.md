---
title: "Geveldegijniet g'een hebt gij niet"
date: 2022-12-13T12:10:11Z
draft: false
tags: ['huis','gevel']
---

Ze zijn begonnen aan de gevel hoeri hoera. Werken voorzien:

- Beschermen van ramen en vloeren
- Plaatsen en verwijderen van stellingen
- Verwijderen van oude verflaag
- Herstellen van beschadigd pleisterwerk
- Herstellen van de gevellijst
- Uitvlakken, schuren en schilderen
- Opkitten met acrylkit van alle binnenhoeken
- Afbranden verf van de dakgoot, opkitten, primen en schilderen in 2 lagen
- Vernieuwen van de afvoerbuis in zink
- Schilderen van plint
- Opkuis en meenemen van alle werfvuil

’t Zal zeker niet meer allemaal klaar zijn in 2022, maar we leven in hoop.
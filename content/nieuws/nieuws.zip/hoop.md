---
title: "Hoop doet leven"
date: 2023-08-13T20:40:08Z
draft: false
tags: ['huis','werk']
---

Er is enige hoop voor wat het <a href="/huis/todo">nog te doen werk in huis</a> betreft: er is een mens die allerlei werk in huis doet en daar allemaal onderaannemers voor heeft, en die zou ons ergens na het einde vna het bouwverlof een offerte sturen voor zo ongeveer alles dat er nog te doen is in huis. 

We zijn ook nog altijd in blije afwachting van een schrijnwerker om de veluxen af te werken. Hoop doet leven, maar ik moet toegeven dat ik er niet enorm hard op reken dat het snel zal zijn. 
---
title: Deploy, v1
date: 2022-12-05T21:58:00Z
draft: false
tags: ['site']
---

Czech it out: zowel {{% hier-en-elders %}} staat dezelfde inhoud. Alletwee met hugo, maar de ene met firebase gesynct en de andere met xcopy naar een share. 

't Is een beetje stom dat ik voor de paragraaf hierboven speciaal een shortcode heb moeten maken, maar hey. 